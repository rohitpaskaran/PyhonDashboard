import plotly.graph_objects as go
from plotly.utils import PlotlyJSONEncoder
import json
import plotly.express as px

class ChartGenerator:
    @staticmethod
    def create_category_price_bar(category_price):
        fig = go.Figure(data=[
            go.Bar(
                x=category_price['category'],
                y=category_price['price'],
                marker_color='rgb(55, 83, 109)'
            )
        ])
        
        fig.update_layout(
            title='Average Price by Category',
            xaxis_title='Category',
            yaxis_title='Average Price ($)',
            template='plotly_white'
        )
        
        return json.dumps(fig, cls=PlotlyJSONEncoder)
    
    @staticmethod
    def create_brand_distribution_pie(brand_count):
        fig = go.Figure(data=[
            go.Pie(
                labels=brand_count['brand'],
                values=brand_count['count'],
                hole=0.3
            )
        ])
        
        fig.update_layout(
            title='Product Distribution by Brand',
            template='plotly_white'
        )
        
        return json.dumps(fig, cls=PlotlyJSONEncoder)
    
    @staticmethod
    def create_posts_per_user_bar(posts_per_user):
        fig = go.Figure(data=[
            go.Bar(
                x=posts_per_user['userId'],
                y=posts_per_user['post_count'],
                marker_color='rgb(158, 202, 225)'
            )
        ])
        
        fig.update_layout(
            title='Number of Posts per User',
            xaxis_title='User ID',
            yaxis_title='Number of Posts',
            template='plotly_white'
        )
        
        return json.dumps(fig, cls=PlotlyJSONEncoder)
    
    @staticmethod
    def create_todos_completion_stacked_bar(todo_status):
        fig = go.Figure(data=[
            go.Bar(name='Completed', x=todo_status['userId'], y=todo_status['sum'],
                  marker_color='rgb(133, 192, 149)'),
            go.Bar(name='Incomplete', x=todo_status['userId'], y=todo_status['incomplete'],
                  marker_color='rgb(219, 147, 147)')
        ])
        
        fig.update_layout(
            title='Todo Completion Status by User',
            xaxis_title='User ID',
            yaxis_title='Number of Todos',
            barmode='stack',
            template='plotly_white'
        )
        
        return json.dumps(fig, cls=PlotlyJSONEncoder)
    


    @staticmethod
    def Create_mine(posts_per_users):
        fig = go.Figure(data=[
            go.Bar(
                x=posts_per_users['userId'],
                y=posts_per_users['postsCount'],
                marker_color='rgb(158, 202, 225)'
            )
        ])
        
        fig.update_layout(
            title='Number of Posts per User',
            xaxis_title='User ID',
            yaxis_title='Number of Posts',
            template='plotly_white'
        )
        
        return json.dumps(fig, cls=PlotlyJSONEncoder)