import requests

class DataFetcher:
    DUMMY_JSON_URL = "https://dummyjson.com"
    PLACEHOLDER_URL = "https://jsonplaceholder.typicode.com"
    myfetcher  = "https://dummyapi.online/api"  
    def fetch_products():
        response = requests.get(f"{DataFetcher.DUMMY_JSON_URL}/products")
        return response.json()
    
    @staticmethod
    def fetch_carts():
        response = requests.get(f"{DataFetcher.DUMMY_JSON_URL}/carts")
        return response.json()
    
    @staticmethod
    def fetch_posts():
        response = requests.get(f"{DataFetcher.PLACEHOLDER_URL}/posts")
        return response.json()
    
    @staticmethod
    def fetch_todos():
        response = requests.get(f"{DataFetcher.PLACEHOLDER_URL}/todos")
        return response.json()
    
    @staticmethod
    def fetch_my():
        response = requests.get(f"{DataFetcher.myfetcher}/social-profiles")
        return response.json()