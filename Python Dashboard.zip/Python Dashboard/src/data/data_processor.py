import pandas as pd

class DataProcessor:
    @staticmethod
    def process_products_data(products_data):
        products = products_data['products']
        df = pd.DataFrame(products)
        
        category_price = df.groupby('category')['price'].mean().reset_index()
        brand_count = df['brand'].value_counts().reset_index()
        brand_count.columns = ['brand', 'count']
        
        return category_price, brand_count
    
    @staticmethod
    def process_posts_data(posts_data):
        df = pd.DataFrame(posts_data)
        # Count posts per user
        posts_per_user = df['userId'].value_counts().reset_index()
        posts_per_user.columns = ['userId', 'post_count']
        posts_per_user = posts_per_user.sort_values('userId')
        return posts_per_user
    
    @staticmethod
    def process_todos_data(todos_data):
        df = pd.DataFrame(todos_data)
        # Calculate completion status per user
        todo_status = df.groupby('userId')['completed'].agg(['sum', 'count']).reset_index()
        todo_status['incomplete'] = todo_status['count'] - todo_status['sum']
        return todo_status
    
    @staticmethod
    def my_process(mydata):
        # Create DataFrame from input data
        df = pd.DataFrame(mydata)
        
        posts_per_user = df['userId'].value_counts().reset_index()
        posts_per_user.columns = ['userId', 'postsCount']
        posts_per_user = posts_per_user.sort_values('userId')
        return posts_per_user
    
        
        return ratings