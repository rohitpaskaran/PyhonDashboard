from flask import Flask, render_template
from src.api.data_fetcher import DataFetcher
from src.data.data_processor import DataProcessor
from src.visualization.charts import ChartGenerator

app = Flask(__name__)

@app.route('/')
def dashboard():
    # Fetch data
    products_data = DataFetcher.fetch_products()
    
    # Process data
    category_price, brand_count = DataProcessor.process_products_data(products_data)
    
    # Create charts
    category_price_chart = ChartGenerator.create_category_price_bar(category_price)
    brand_distribution_chart = ChartGenerator.create_brand_distribution_pie(brand_count)
    
    return render_template('dashboard.html',
                         category_price_chart=category_price_chart,
                         brand_distribution_chart=brand_distribution_chart)

@app.route('/statistics')
def statistics():
    # Fetch data
    posts_data = DataFetcher.fetch_posts()
    todos_data = DataFetcher.fetch_todos()
    
    # Process data
    posts_per_user = DataProcessor.process_posts_data(posts_data)
    todo_status = DataProcessor.process_todos_data(todos_data)
    
    # Create charts
    posts_chart = ChartGenerator.create_posts_per_user_bar(posts_per_user)
    todos_chart = ChartGenerator.create_todos_completion_stacked_bar(todo_status)
    
    return render_template('statistics.html',
                         posts_chart=posts_chart,
                         todos_chart=todos_chart)




@app.route('/mine')
def mine():
    # Fetch data
    mydata = DataFetcher.fetch_my()
    
    # Process data
    mydatayser = DataProcessor.my_process(mydata)
    
    # Create charts
    posts_chartss = ChartGenerator.Create_mine(mydatayser)
    
    return render_template('mine.html',
                         posts_chart=posts_chartss)



if __name__ == '__main__':
    app.run(debug=True)